(ns integer-arithmetic.core
  (:require [clojure.pprint :refer :all]))

(import 'java.lang.ArithmeticException)

(defmacro dump-strings-and-values
  "Produces parallel vectors of printable dump strings and values. A dump string
  shows an expression, unevaluated, then a funny arrow, then the value of the
  expression."
  [& xs]
  `(apply map vector ;; transpose
          (for [x# '~xs
                v# [(try (eval x#) (catch Exception e# (str e#)))]]
            [(str x# " ~~> " v#) v#])))

(dump-strings-and-values (* 7 6))
(dump-strings-and-values (* 7 6) (/ 1 0))

(defmacro hashmap-expressions-and-values
  "Produces a hashmap of unevaluated expressions and their values. "
  [& xs]
  `(let [pairs#
         (for [x# '~xs
               v# [(try (eval x#) (catch Exception e# (str e#)))]]
           [x# v#])]
     [(last (last pairs#))
      (into {} pairs#)]))

(hashmap-expressions-and-values (* 7 6))
(hashmap-expressions-and-values (* 7 6) (/ 1 0))

(defmacro vdump
  "Prints a hashmap of unevaluated expressions and their values by side
  effect. Produces the last value from its inputs."
  [& xs]
  `(let [[v# h#] (hashmap-expressions-and-values ~@xs)]
     (clojure.pprint/pprint h#)
     v#))

(vdump (* 6 7))
(vdump (/ 1 0))
(vdump (* 7 6) (/ 1 0) (into {} [[:a 1]]))

(defn euclidean-quotient [^Integer n ^Integer d]
  "Produces the quotient of integers n (numerator) and d (denominator) by
   Euclid's method of antanaresis. See
   https://www.britannica.com/biography/Euclid-Greek-mathematician and
   https://en.wikipedia.org/wiki/Euclidean_algorithm."
  (if (= d 0) (throw (ArithmeticException. "")))
  (loop [q -1      ;; bind q to -1, and
         t  n]     ;; bind t to n, then start computing ...
    ;; (println)
    (if (< t 0)    ;; if (< t 0) == t < 0 (move binary operator to the right)
      q            ;; true branch
      (recur       ;; false branch: goto "loop" ...
       (inc q)     ;; with q bound to (inc q)
       (- t d))))) ;; and t bound to (- t d) == t-d

(defn corrected-euclidean-quotient [^Integer n ^Integer d]
  "Produces the quotient of integers n (numerator) and d (denominator) by
   Euclid's method of antanaresis. See
   https://www.britannica.com/biography/Euclid-Greek-mathematician and
   https://en.wikipedia.org/wiki/Euclidean_algorithm."
  (if (= d 0) (throw (ArithmeticException. "")))
  (letfn [(sign [x] (if (< x 0) -1 1))]
    (let [cn (java.lang.Math/abs n)
          cd (java.lang.Math/abs d)
          sn (sign n)
          sd (sign d)]
      ;; (pdump cn) (pdump cd) (pdump sn) (pdump sd)
      (loop [q -1      ;; bind q to -1, and
             t  cn]    ;; bind t to n, then start computing ...
        ;; (pdump q)
        ;; (pdump t)
        ;; (println)
        (if (< t 0)    ;; if (< t 0) == t < 0 (move binary operator to the right)
          (* sn sd q)  ;; true branch
          (recur       ;; false branch: goto "loop" ...
           (inc q)     ;; with q bound to (inc q)
           (- t cd)))))))
